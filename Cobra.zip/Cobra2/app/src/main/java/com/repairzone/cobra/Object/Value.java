package com.repairzone.cobra.Object;

import java.util.List;

public class Value {
    String value;
    String message;
    List<Item> result;

    public String getValue() {
        return value;
    }

    public String getMessage() {
        return message;
    }

    public List<Item> getItemList(){
        return result;
    }
}

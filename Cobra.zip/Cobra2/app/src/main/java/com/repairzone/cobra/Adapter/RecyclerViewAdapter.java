package com.repairzone.cobra.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.repairzone.cobra.Object.Item;
import com.repairzone.cobra.R;

import java.util.List;

import butterknife.BindView;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    private Context context;
    private List<Item> itemList;

    public RecyclerViewAdapter(Context context, List<Item> itemList){
        this.context = context;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_view, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Item result = itemList.get(position);
        holder.tx_item.setText(result.getNama());
        holder.tx_jumlah.setText(result.getJumlah());
        holder.tx_satuan.setText(result.getSatuan());
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        @BindView(R.id.textItem) TextView tx_item;
        @BindView(R.id.textJumlah) TextView tx_jumlah;
        @BindView(R.id.textSatuan) TextView tx_satuan;

        public ViewHolder(View view){
            super(view);
        }
    }
}

package com.repairzone.cobra;

public class Configuration {
    public static final String BASE_URL = "https://logistiku.000webhostapp.com";
}

package com.repairzone.cobra.Fragment;


import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.repairzone.cobra.API.DatabaseAPI;
import com.repairzone.cobra.Adapter.RecyclerViewAdapter;
import com.repairzone.cobra.Configuration;
import com.repairzone.cobra.Object.Item;
import com.repairzone.cobra.Object.Value;
import com.repairzone.cobra.R;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


/**
 * A simple {@link Fragment} subclass.
 */
public class StockList extends Fragment {

    View view;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    RecyclerViewAdapter recyclerViewAdapter;
    List<Item> itemList = new ArrayList<>();
    public StockList() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_stock_list, container, false);
        Context context = view.getContext();
        ButterKnife.bind(view);
        recyclerViewAdapter = new RecyclerViewAdapter(context, itemList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity().getBaseContext()));
        recyclerView.setAdapter(recyclerViewAdapter);

        loadItemList();
        return view;
    }

    private void loadItemList() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Configuration.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        DatabaseAPI api = retrofit.create(DatabaseAPI.class);
        Call<Value> call = api.listItem();
        call.enqueue(new Callback<Value>() {
            @Override
            public void onResponse(Call<Value> call, Response<Value> response) {
                String value = response.body().getValue();

                    itemList = response.body().getItemList();
                    recyclerViewAdapter = new RecyclerViewAdapter(view.getContext(), itemList);
                    recyclerView.setAdapter(recyclerViewAdapter);

            }

            @Override
            public void onFailure(Call<Value> call, Throwable t) {
                Toast.makeText(view.getContext(), "Tidak Bisa....", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
